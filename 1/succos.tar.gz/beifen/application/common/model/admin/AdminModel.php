<?php
namespace app\common\model\admin;

use think\Model;

class AdminModel extends Model{
    protected $pk='admin_id';
    protected $name='admin';
}